import firebase_admin
from firebase_admin import credentials, firestore
cred = credentials.Certificate("Database/musiclab-3ab61-firebase-adminsdk-qeygj-003eb91fdb.json")
firebase = firebase_admin.initialize_app(cred)
db = firestore.client()
